FIWeatherWatch v0.1.4 — beta, for Peter
=======================================

Finnish weather on the watch: land forecast, marine wind, and wave data
from the Finnish Meteorological Institute.

Defaults are already set for you:
  Land ......... Karjaa
  Sea station .. Hanko Russarö
  Wave buoy .... Suomenlahti

All of them can be changed afterwards in Garmin Connect Mobile
(Connect IQ Apps -> FIWeatherWatch -> Settings).


TO INSTALL
----------
1. Connect the watch to the computer with the USB cable.
2. It appears as a drive called GARMIN.
3. Copy  fiweatherwatch.prg           to  GARMIN/APPS/
4. Copy  fiweatherwatch-settings.json to  GARMIN/APPS/SETTINGS/
5. Eject the drive and unplug. The app appears in the widget
   carousel (press UP or DOWN from the watch face).

Built for fenix 8 47mm / quatix 8 47mm.


HOW TO USE IT
-------------
Four pages, swipe up/down:
  1. Land    temperature, wind + gust, forecast for the rest of the day
  2. Sea     wind, gust, direction and air temperature at the station
  3. Waves   wave height, period, direction, water temperature
  4. About   version and data credits

Press SELECT (top right) to refresh.

A number turns orange when it crosses a limit you have set, blue when
cold, red when hot. The limits are in the settings — the defaults are
wind 5 m/s on land, 10 m/s at sea, waves 1 m.

The bottom line of each page shows how old the reading is and which
build you are on. That version number is useful in a bug report.


WORTH KNOWING
-------------
* Karjaa has no weather station of its own. The nearest one that
  reports is Inkoo Jakobramsjö, about 20 km away — the app names the
  station and shows the distance so you can see where the number
  came from.

* The Suomenlahti buoy is about 130 km from Russarö. All the wave
  buoys are a long way from Hanko, so treat wave height as "the sea
  area", not "off the point".

* Wave buoys are lifted out of the water roughly December to April.
  When none is reporting, the app says so and falls back to model
  output, clearly labelled.

* If the phone is out of range the last reading stays on screen and
  says that it is the last reading, rather than going blank.


FEEDBACK
--------
Anything odd, please note the version from the bottom of the page
and what the screen said. Screenshots are ideal.

Live version of the same data: https://weatherapp.tallimedia.com

Weather data: Finnish Meteorological Institute, CC BY 4.0.
Independent project, not affiliated with FMI or Garmin.
